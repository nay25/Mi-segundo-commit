<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<!--Archivo de enlace a la carpeta inicio-->
</body>

<script>
	window.location="inicio/index.php"
</script>
</html>

